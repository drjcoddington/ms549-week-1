#pragma once
#include <string>

using namespace std;

int menu();
void blastoff();
void addStr(string str1, string str2);


