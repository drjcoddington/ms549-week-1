#include <iostream>
#include <string>
#include "functions.h"

using namespace std;

int main()
{
	bool notDone = true;
	while (notDone)
	{
		int option = menu();
		//	cout << "you chose " << option << "more text" << endl;
		if (option == 1)
		{
			blastoff();
		}
		else if (option == 2)
		{
			addStr("JIll ", "Coddington");
		}
		else
		{
			notDone = false;
		}
	}
	return 0;
}